#include <complex.hpp>
#include <cmath>

ComplexNumber::ComplexNumber()
{
    m_real = 0.0;
    m_imag = 0.0;
}

ComplexNumber::ComplexNumber(double x, double y)
{
    m_real = x;
    m_imag = y;
}

ComplexNumber::~ComplexNuber()
{
    // to-do
}

double ComplexNumber::mod() const
{
    double res = sqrt(pow(m_real, 2) + pow(m_imag, 2));
    return res;
}

double ComplexNumber::arg() const
{
    //  to-do
}

ComplexNumber ComplexNumber::operator*(const ComplexNumber other_z)
{
    // x = (a +b i)
    //  y = (c + d i)
    //  x* y  = a*c -b*d + (a*d + b*c) i
    double real = m_real * other_z.m_real - m_imag * other_z.m_imag;
    double imag = m_real * other_z.m_imag + m_imag * other_z.m_real;
    ComplexNumber res = ComplexNumber(real, imag);
    return res;
}

ComplexNumber ComplexNumber::operator+(const ComplexNumber other_z)
{
}

ComplexNumber ComplexNumber::operator-(const ComplexNumber other_z)
{
}

std::ostream &operator<<(std::ostream &output, const ComplexNumber &z)
{
    // std::cout << z << "\n";  -> (a + b * i)
    output << "(" << z.m_real << " + " << z.m_imag << " * i";
    // to-do, logic control
}