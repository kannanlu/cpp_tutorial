//  a + bi  = (double a , double b)
// mod(a + bi), arg(a + bi)
//  pow(a+bi)
//  (a + bi) +   (x+yi)

#include <iostream>

class ComplexNumber
{
private:
    // private data (m_real + m_imag * 1j)
    double m_real;
    double m_imag;

public:
    // default constructor
    ComplexNumber();
    ComplexNumber(double m_real, double m_imag);
    // copy constructor
    ~ComplexNuber();
    // method use the data
    // x = ComplexNumber(1 , 2) , x.mod(), x.arg()
    double mod() const;
    double arg() const;
    // operator*, operator+, operator-,
    ComplexNumber operator*(const ComplexNumber other_z);
    ComplexNumber operator+(const ComplexNumber other_z);
    ComplexNumber operator-(const ComplexNumber other_z);
    // operator print   std::cout << a
    friend std::ostream &operator<<(std::ostream output, const ComplexNumber);
};
